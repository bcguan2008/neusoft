/**
 * (description)
 * 
 * @author yourname
 */

export default class DetailController {
  constructor() {
    this.name = 'detail';
  }
}