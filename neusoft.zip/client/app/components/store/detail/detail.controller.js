/**
 * (description)
 * 
 * @author anyunfei
 */

export default class DetailController {
  constructor() {
    this.name = 'detail';
  }
}