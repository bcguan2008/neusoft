/**
 * store
 * @author guanbingchang@wanda.cn
 */

import list from './list/list';

export default angular.module('app.staff', [
    list.name
]);

