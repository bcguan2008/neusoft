/**
 * (description)
 * 
 * @author yourname
 */

export default class ListController {
  constructor() {
    this.name = 'list';
  }
}