import template from './add.html';
import controller from './add.controller';
import './add.less';

export default {
  restrict: 'E',
  bindings: {},
  template,
  controller,
  controllerAs: 'vm'
};
