/**
 * (description)
 * 
 * @author yourname
 */

export default class AddController {
  constructor() {
    this.name = 'add';
  }
}