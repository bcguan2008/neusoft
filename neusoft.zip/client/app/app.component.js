/**
 * app component
 * @author name emailAddress
 */

'use strict';

import template from './app.html';

let appComponent = {
  template,
  restrict: 'E'
};

export default appComponent;
