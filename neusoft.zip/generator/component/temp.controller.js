/**
 * (description)
 * 
 * @author yourname
 */

export default class <%= upCaseName %>Controller {
  constructor() {
    this.name = '<%= name %>';
  }
}